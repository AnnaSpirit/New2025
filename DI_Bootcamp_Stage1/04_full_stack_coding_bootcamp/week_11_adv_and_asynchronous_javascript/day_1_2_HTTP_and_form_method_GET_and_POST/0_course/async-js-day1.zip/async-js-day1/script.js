/** Async in JS */
/** Callback */


// setTimeout(()=>{
//    console.log('hi');
// }, 5 *1000)

/** Callback */
function myCallback() {
  console.log("my callback executed!");
}

function exeCallback(func) {
  func();
}

// exeCallback(myCallback)

function getX(callback) {
  setTimeout(() => {
    callback(5);
  }, 2000);
}

function getY(func) {
  setTimeout(() => {
    func(6);
  }, 5 * 1000);
}

function getXY() {
  getX((x) => {
    console.log(" x from callback=>", x);
    getY((y) => {
      console.log("y=>", y);
      console.log(x + y);
    });
  });
//   //   let x = getX();
//   //   console.log("x=>", x);
//   //   let y = getY();
//   //   console.log("y=>", y);

//   //   let sum = x + y;
//   //   console.log("sum=>", sum);
}

// getXY();

/** callback hell */

function boilWater(callback) {
  console.log("Boiling water...");
  setTimeout(() => {
    callback("hot water");
  }, 5 * 1000);
}
function getTeabag(callback) {
  console.log("Getting a teabag...");
  setTimeout(() => {
    callback("green tea");
  }, 2000);
}

function makeTea(water, tea, callback) {
  callback(`Making a nice cup of tea...`);
  setTimeout(() => {
    callback(`A nice cup of ${tea} with ${water}`);
  }, 1000);
}

function prepareTea() {
  boilWater((water) => {
    getTeabag((tea) => {
      makeTea(water, tea, (make) => {
        console.log(make);
      });
    });
  });
  /** boil the water */
  //   let water = boilWater();
  //   console.log("water=>", water);
  //   /** tea bag */
  //   let tea = getTeabag();
  //   console.log("tea=>", tea);
  //   /** make tea */
  //   let cup = makeTea(water, tea);

  //   return cup;
}
// prepareTea();
// console.log(prepareTea());

/** Promise */
/** pending */
/** fullfiled - resolve */
/** fullfiled - reject */

// let promise1 = new Promise((resolve, reject) => {
//   reject('opps...');
// });

// console.log(promise1);

// let p = new Promise((res, rej) => {
//   setTimeout(() => {
//     rej("no hello");
//   }, 3000);
// });

// console.log(p);

// p.then((val) => {
//   console.log(val);
// }).catch((e) => {
//   console.log(e);
// });

function getX() {
  return new Promise((res, rej) => {
    setTimeout(() => {
      res(5);
    }, 2 * 1000);
  });
}

function getY() {
  return new Promise((res) => {
    // if(val === undefined) rej(' no value')
    setTimeout(() => {
      res(6);
    }, 5000);
  });
}

function getXY() {
  getX()
    .then((x) => {
      console.log("x=>", x);
      getY()
        .then((y) => {
          console.log("y=>", y);
          console.log(x + y);
        })
        .catch((e) => {
          console.log(e);
        });
    })
    .catch((e) => {
      console.log(e);
    });
}

// getXY();

const flip = () => {
  const coin = Math.floor(Math.random() * 2);
  return coin === 0 ? "head" : "tail";
};

// console.log(flip());

// const flipcoin = new Promise((res, rej) => {
//   setTimeout(() => {
//     const result = flip();
//     if (result === "head") {
//       res("you win=>" + result);
//     } else {
//       rej("you lose=>" + result);
//     }
//   }, 2 * 1000);
// });
// console.log(flipcoin);

// flipcoin
//   .then((result) => {
//     // console.log(result);
//     return result + " champion";
//   })
//   .then((data) => {
//     // console.log(data);
//     return data + " you are the best";
//   })
//   .then((data) => {
//     console.log(data);
//   })
//   .catch((result) => {
//     console.log(result);
//   });

/** Promise static method */

// Promise.reject('no value')
// Promise.resolve(5)

function getNum(num) {
  //   return new Promise((res) => {
  //     res(5);
  //   });
  if(num) return Promise.resolve(num);
  return Promise.reject(-1)
}

// getNum()
//  .then(val => {
//     console.log(val);
//  })
//  .catch(e => {
//     console.log(e);
//  })

// Promise.all(arrayOfPromises)
// Promise.allSettled(arrayOfPromises)
// Promise.race(arrayOfPromises)
// Promise.any(arrayOfPromises)

const promise1 = Promise.resolve('resolve promise 1')
// const promise2 = Promise.resolve('resolve promise 2')
const promise2 = Promise.reject('reject promise 2')
const promise3 = Promise.resolve('resolve promise 3')

let arryOfPromises = [promise2,promise1,promise3]
console.log(arryOfPromises);

Promise.any(arryOfPromises)
 .then(res => {
    console.log(res);
 })
 .catch(e => {
    console.log(e);
 })