/** Object & Class*/

let user = {
  email: "jjj@gmail.com",
  age: 25,
  address: {
    city: "TLV",
  },
};

// console.log(user["name"]);

/** loop an object */
for (const x in user) {
  // console.log(x, user[x]);
}

/** Object methods */

let userKeys = Object.keys(user);
// console.log(userKeys);
// userKeys.forEach(x=>{
//   console.log(x);
// })

let userValues = Object.values(user);

let userEnteries = Object.entries(user);
// console.log(userEnteries);
// userEnteries.forEach(([key, value]) => {
//   // console.log(key, value);
// });

let arr = [
  ["name", "Anne"],
  ["age", 23],
  ["gender", "F"],
];

let anneUser = Object.fromEntries(arr);
// console.log(anneUser);

/** Object Destructuring */

let a = user.name;
let b = user.email;
let c = user.age;

// console.log(a, b, c);

let {
  name,
  email,
  age,
  address: { city },
} = user;
// console.log(name, age, email, city);

function getUserInfo({ name, age, email, address: { city } }) {
  // let { name, age, email, address:{city}} = user
  if (name === undefined) name = "x";
  return name + " # " + age + " # " + email + " # " + city;
}

// console.log(getUserInfo(user));

/** spreading */
let obj = {
  a: 1,
  b: "abc",
};
// console.log(obj);

let newObj = { ...obj, c: 5, a: "jhon", ...[1, 2, 3], ...{ g: "g" } };
// console.log(newObj);


/** classes */
class Animal {
  constructor(nameParam, typeParam) {
    this.name = nameParam;
    this.type = typeParam;
  }
  getAnimalInfo() {
    return `${this.name} is a ${this.type}`;
  }

  setName(value) {
    this.name = value;
  }

  getName() {
    return this.name;
  }

  set animalType(value) {
    this.type = value;
  }

  get animalType() {
    return this.type;
  }
}

const myDog = new Animal("Shadow", "Dog");
// const myCat = new Animal('CatCat', 'Cat');

// console.log(myDog);
// myDog.setName('Spoty')
// myDog.animalType = 'Horse'
// console.log(myDog.animalType);
// console.log(myDog.getAnimalInfo());
// console.log(myDog.getName());
// // console.log(myCat);
// console.log(myCat.getAnimalInfo());

class Dog extends Animal {
  constructor(dogname, dogcolor) {
    super(dogname, "Dog");
    this.color = dogcolor;
  }
  getDogInfo() {
    // return `${this.name} is a ${this.type}, ${this.color} color`
    return this.getAnimalInfo() + `, ${this.color} color`;
  }
  getDogName() {
    return this.name + "...";
  }
}

const newDog = new Dog("Kuku", "Black & White");
console.log(newDog.getDogInfo());
console.log(newDog.getName());
// console.log(newDog);

const friendDog = new Dog("Holu", "Brown");
// console.log(friendDog.getDogInfo());

class FrenchiDog extends Dog {}

