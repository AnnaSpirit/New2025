/** scope */
const a = "abc";
{
  var b = 0;
  //   console.log(a);
}

// console.log(b);
// console.log(a);

for (var i = 0; i < 5; i++) {}

// console.log(i);

// const vat = 1.17;
/**
 *
 *
 *
 *
 *
 *
 */
// console.log(vat);
// const vat = 1.5;

// console.log(vat);
function priceWithVat(price, vat = 0.18) {
  // if(vat === undefined) {
  //     vat = 0.18
  // }
  return price + price * vat;
}

let productPrice = priceWithVat(100);
// console.log(productPrice);
// let x = 3;
// if (x > 3) {
// //   console.log("greater");
// } else {
// //   console.log("less");
// }

// let msg = (x > 3) ? 'greater' : (x === 3) ? 'equal' : 'less';
// console.log(msg);

/**
 * condition ? ... : ...
 */

/** `...` */
// console.log('the message is \n' + msg +
// ' . end of message');
// console.log(`the
// message is ${msg}
// end of messgae`)

// const greeting = 'hello student of class 158'

// console.log(document.getElementById('root'));
// document.getElementById('root').innerHTML = `<h2>${greeting}</h2>`

// getName('aaa')
// function getName(param) {
//     return param
// }

// const getName = function(param) {
//     return param
// }

// const getName = (param) => {
//     return param
// }

// const getName = param => param
// const sumAB = (a,b) => a + b
// getName('aaa')

// function main(){
//     /** start you application */
// }
// main()

// (function(){
// console.log('hello');
// })()

// function x() {
//     let name = 'Dan'
//     let a = 3
//     let b = 6
//     function y(){
//         let name = 'John'
//         let b = 4
//         return a + b
//     }
//     console.log(b);
//     return y
// }

// let sum = x()()
// console.log(sum);

// const add = (a) => (b) => a + b;

// const add1 = (a) => (b) => a + b;

// const twoDim = add(1.18);
// console.log(twoDim(200));
// console.log(twoDim(400));
// console.log(twoDim(600));

/**
 * Pass by Value and Pass by Reference
 */

let param1 = 8;
let param2 = param1;
param2 = 10;
// console.log(param1);
// console.log(param2);
/** array / object reference */
let obj1 = {
  a: 10,
  b: 5,
};

let obj2 = obj1;

obj2.b = 11;

// console.log(obj1);
// console.log(obj2);

let arr1 = [1, 2, 3];
let arr2 = arr1;

arr2[1] = 5;

// console.log(arr1);

/** clone */
let obj3 = { ...obj1 };
let obj4 = Object.assign({}, obj1);
obj3.b = 55;
// console.log(obj1);
// console.log(obj3);
// console.log(obj4);

let arr3 = [...arr1];
let arr4 = [].concat(arr1);

// console.log(arr3);
// console.log(arr4);

let obj5 = {
  a: 5,
  c: {
    b: 6,
  },
};

let obj6 = { ...obj5 };

obj6.a = 11;
obj6.c.b = 0;

// console.log(obj5);
// console.log(obj6);

let obj7 = JSON.stringify(obj5);
// console.log(obj7);
obj7 = JSON.parse(obj7);
// console.log(obj7);





/** object */
let object1 = {};
let object2 = new Object();

object1.name = "John";
object1["lastname"] = "Due";

console.log(object1.lastname);
console.log(object1["name"]);

/**  */
let column1 = "age";
object1[column1] = 17;
console.log(object1);

/** */
const name = "Anne";
const age = 25;

let user = {
  name,
  age,
  x: function(){}
};

console.log(user);



let newObj =  {...user}//structuredClone(user);
console.log(newObj);

// for (const x in user) {
//   console.log(x);
//   console.log(user[x]);
// }

const newVar = 1;
// newVar = 2

const newObj1 = { a: 3 };
newObj1.a = 2;
