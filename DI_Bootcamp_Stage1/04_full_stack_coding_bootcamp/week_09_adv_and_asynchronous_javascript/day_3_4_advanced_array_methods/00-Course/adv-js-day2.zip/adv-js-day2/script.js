for (let i = 0; i < 5; i++) {}

for (let i of [1, 2, 3]) {
}

for (let i in [1, 2, 3]) {
}

for (let i in { a: 1, b: 10 }) {
}

/** forEach */
/**
 * @param
 * item/element - mndatory
 * index - optional
 * array - optional
 */
let arr = [];
users.forEach((item, i, myarr) => {
  // console.log(item, i);
  arr.push(item + "@gmail.com");
  myarr[i] = item + "@gmail.com";
});
console.log(users);
console.log(arr);


/** map
 * @param
 * item
 * index - optional
 * @returns a new array
 */

let myarr = [1, 2, 3, 4];

let result = myarr.map((item, i) => {
  if (item > 2) return item * i;
});
// console.log(result);

/** filter
 * @returns a new filltered array
 */

let filteredArr = myarr.filter((item) => {
  return item > 2;
});

// console.log(filteredArr);



/**
 * find / findIndex
 */

// let user = users.find( item => {
//     return item.id > 2
// })

let user = users.findIndex((item) => {
  return item.id > 1;
});

// console.log(user);


let arr = [2, 5, 10, 100];

let sum = arr.reduce((total, item) => {
  return total + item;
}, 3);

// console.log(sum);

/** some / every */

let match = arr.some(a => {
  return a == 2
})

let match = arr.every((a) => {
  return a > 2;
});

// console.log(match);

/** array destructuring */

let array = [1, 2, 33, 4, 5];
let a = array[0];
let b = array[1];
let c = array[3];

let [c3, b2, a1] = array;
// console.log(a1,b2,c3);

/** rest parameters */
let [d, e, ...rest] = array;
// console.log(d,e, rest);

/** spead operator */
let arr1 = [1, 2];
let arr2 = ["a", "b"];

let arr3 = [...arr2, ...arr1];

// console.log(arr3);
