import "./App.css";
// import Hello from "./Hello";
import User from "./components/User";
import users from "./users.json";

// const users = [
//   { id: 1, name: "John", username: "johnjohn", email: "jjj@gmail.com" },
//   { id: 2, name: "Anne", username: "anneanne", email: "aaa@gmail.com" },
//   { id: 3, name: "Dan", username: "dandan", email: "ddd@gmail.com" },
//   { id: 4, name: "Marry", username: "mama", email: "mmm@gmail.com" },
//   { name: "Alex" },
//   { email:'abc@gmail.com'}
// ];

function App() {
  return (
    <>
      {users.map((item) => {
        return <User userinfo={item} />;
      })}

      {/* <User name='John' username='johnjohn' email='jjj@gmail.com' />
      <User name='Anne' username='anneanne' email='aaa@gmail.com' />
      <User name='Dan' username='dandan' email='ddd@gmail.com' /> */}
    </>
  );
}

export default App;
