import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import "./index.css";
import App from "./App.jsx";

let element = (
  <h1>
    Hello!
    {1 + 1}
  </h1>
);

createRoot(document.getElementById("root")).render(<App />);
