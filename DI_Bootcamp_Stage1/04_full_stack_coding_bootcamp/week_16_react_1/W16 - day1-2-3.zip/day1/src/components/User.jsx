import './user.css'
// import Button from '@mui/material/Button';
import {Button} from '@mui/material';
import Slider from '@mui/material/Slider';
// import VolumeDown from '@mui/icons-material/VolumeDown';
// import VolumeUp from '@mui/icons-material/VolumeUp';

const User = ({ userinfo }) => {
  // console.log(props);
  // const { userinfo } = props;
  const { name, username, email, phone } = userinfo;

  const styleOptions = {
    display: "inline-block",
    border: "1px solid #000",
    borderRadius: "12px",
    padding: "20px",
    margin: "20px",
    textAlign: "center",
    backgroundColor: "lavenderblush",
  };

  return (
    <div className='box'>
      <h2>{name}</h2>
      <h4>{username}</h4>
      <p>{email}</p>
      <p>{phone}</p>
      <Button variant="contained">Contained</Button>
      <Slider aria-label="Volume" value={10}  />
    </div>
  );
};
export default User;
