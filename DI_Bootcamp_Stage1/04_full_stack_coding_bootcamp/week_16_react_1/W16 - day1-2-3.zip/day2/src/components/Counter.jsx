import { useState } from "react"; /** hook */
// const [state, setState] = useState()

const Counter = () => {
  //   let count = 10;
  const [count, setCount] = useState(10);

  const increment = () => {
    // count++;
    setCount((prev) => prev + 3);
    // setCount((prev) => prev + 1);
    // setCount((prev) => prev + 1);
    // console.log(count);
  };
  const decrement = () => {
    // count--;
    setCount(count - 1);
    // console.log(count);
  };

  return (
    <div>
      <h2>Count = {count}</h2>
      <button onClick={() => increment()}> + </button>
      <button onClick={() => decrement()}> - </button>
    </div>
  );
};
export default Counter;
