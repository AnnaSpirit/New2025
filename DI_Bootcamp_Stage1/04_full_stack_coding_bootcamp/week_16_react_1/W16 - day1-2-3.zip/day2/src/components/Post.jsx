// export default function Post() {
const Post = (props) => {
  //   console.log(props);
  const { title, body, show } = props;

  if (show === "title") {
    return (
      <div>
        <h2>{title}</h2>
      </div>
    );
  }

  if (show === "body") {
    return (
      <div>
        <p>{body}</p>
      </div>
    );
  }

  return (
    <div>
      <h2>{title}</h2>
      <p>{body}</p>
    </div>
  );
};
export default Post;
