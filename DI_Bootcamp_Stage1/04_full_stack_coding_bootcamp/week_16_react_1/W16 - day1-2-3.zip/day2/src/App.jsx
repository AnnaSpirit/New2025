import "./App.css";
import Post from "./components/Post";
import Counter from "./components/Counter";
import { useState } from "react";

// const posts = [
//   { title: "Title 1", body: "my title one body", show: "title" },
//   { title: "Title 2", body: "my title two body", show: "body" },
//   { title: "Title 3", body: "my title three body", show: "" },
// ];

function App() {
  const [posts, setPosts] = useState([
    { title: "Title 1", body: "my title one body", show: "" },
    { title: "Title 2", body: "my title two body", show: "" },
    { title: "Title 3", body: "my title three body", show: "" },
  ]);

  const handleClick = () => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then((res) => res.json())
      .then((data) => {
        console.log(data);
        setPosts(data);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const handleInput = (e) => {
    console.log(e.target.value);
  };

  return (
    <>
      <Counter />
      {/* <div>
        <button onClick={(e) => handleClick(e)}>Get Posts</button>
         <input onChange={(e) => handleInput(e)} placeholder='Search' /> 
      </div> */}
      {/* {posts.map((post, indx) => {
        return (
          <Post
            key={indx}
            title={post.title}
            body={post.body}
            show={post.show}
          />
        );
      })} */}
    </>
  );
}

export default App;
