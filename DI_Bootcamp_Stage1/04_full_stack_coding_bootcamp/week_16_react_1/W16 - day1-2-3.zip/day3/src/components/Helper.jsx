const Helper = (props) => {
  console.log("Helper=>", props);
  return (
    <>
      <div>
        <h2>Helper Function Component</h2>
      </div>
    </>
  );
};
export default Helper;
