import React, { Component } from "react";

class HelperClass extends React.Component {
  constructor() {
    super();
    this.state = {
      count: 10,
    };
  }

  componentDidMount = () => {};
  componentDidUpdate = (prevProps, prevState) => {};
  componentWillUnmount = () => {};

  increment = () => {
    // this.state.count++
    this.setState({ count: this.state.count + 1 });
  };

  render() {
    console.log("HelperClass=>", this.props);
    return (
      <>
        <h2>Helper Class Componet</h2>
        <h2>{this.state.count}</h2>
        <button onClick={() => this.increment()}> + </button>
      </>
    );
  }
}

export default HelperClass;
