import { useState, useEffect } from "react";

const Counter = ({ title, showTitle, countFromApp, setCountFromApp }) => {
    const [count, setCount] = useState(10);
  //   const { title } = props;
  //   console.log(countFromApp, setCountFromApp);

  useEffect(() => {
    return () => {
      alert("Please don't remove me from page");
    };
  }, []);

  const increment = (value) => {
    // console.log("increment", value);
    // setCount(count + 3);
    // setCount(count + 2);
    setCountFromApp(countFromApp + 1);
  };

  if (showTitle) {
    return (
      <div>
        <h2>{title}</h2>
        <h2>{countFromApp}</h2>
        <button onClick={() => increment(1)}> + </button>
      </div>
    );
  }

  return <div></div>;
};
export default Counter;
