import "./App.css";
import Helper from "./components/Helper";
import HelperClass from "./components/HelperClass";

function App() {
  return (
    <>
      <Helper />
      <HelperClass />
    </>
  );
}

export default App;

// import "./App.css";
// import { useState, useEffect } from "react";
// import Counter from "./components/Counter";

// function App() {
//   const [appcount, setAppCount] = useState(1);
//   const [users, setUsers] = useState();
//   const [userId, setUserId] = useState(1);
//   const [showCounter, setShowCounter] = useState(true);

//   useEffect(() => {
//     getUsers();
//     console.log("userId=>", userId);
//     if (userId == 0) {
//       setUserId(5);
//     }
//   }, [userId]);

//   const getUsers = async () => {
//     try {
//       const res = await fetch(
//         `https://jsonplaceholder.typicode.com/users?id=${userId}`
//       );
//       const data = await res.json();
//       // console.log(data);
//       setUsers(data);
//     } catch (error) {
//       console.log(error);
//     }
//   };
//   return (
//     <>
//       <button onClick={() => setShowCounter(!showCounter)}> Click!</button>
//       <div>
//         {showCounter ? (
//           <Counter
//             title='Counter one'
//             showTitle={true}
//             countFromApp={appcount}
//             setCountFromApp={setAppCount}
//           />
//         ) : null}
//       </div>
//       {/* <Counter
//         title='Counter one'
//         showTitle={true}
//         countFromApp={appcount}
//         setCountFromApp={setAppCount}
//       /> */}
//       {/* <Counter title='Counter two' showTitle={true} /> */}
//       <button onClick={() => getUsers()}>Get Users</button>
//       <div>
//         <input onChange={(e) => setUserId(e.target.value)} />
//       </div>
//       <div>
//         {users &&
//           users.map((item) => {
//             return <div key={item.id}>{item.name}</div>;
//           })}
//       </div>
//     </>
//   );
// }

// export default App;
