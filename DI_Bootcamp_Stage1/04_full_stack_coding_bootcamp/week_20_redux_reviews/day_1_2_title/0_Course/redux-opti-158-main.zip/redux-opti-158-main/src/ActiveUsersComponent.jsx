import { memo, useCallback } from 'react';
import { useSelector, shallowEqual } from 'react-redux';
import { selectActiveUsers } from './selectors';


const ActiveUsersComponent = memo(() => {
  console.log('ActiveUsersComponent is rendering...', new Date().toLocaleTimeString());
  
  // Use shallowEqual to ensure we only re-render if the array items actually change
  const activeUsers = useSelector(selectActiveUsers, shallowEqual);
  console.log('Active users count:', activeUsers.length);

  // Memoize the rendered list items
  const renderUser = useCallback((user) => (
    <li key={user.id}>{user.name}</li>
  ), []);

  return (
    <ul>
      {activeUsers.map(renderUser)}
    </ul>
  );
});

ActiveUsersComponent.displayName = 'ActiveUsersComponent';

export default ActiveUsersComponent;