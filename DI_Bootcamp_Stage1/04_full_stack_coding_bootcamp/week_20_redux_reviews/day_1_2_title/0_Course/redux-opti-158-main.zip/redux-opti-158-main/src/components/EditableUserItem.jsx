import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { updateUserName } from '../slices/usersSlice';

const EditableUserItem = ({ user }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [editedName, setEditedName] = useState(user.name);
  const dispatch = useDispatch();

  const handleClick = () => {
    if (!isEditing) {
      setIsEditing(true);
    }
  };

  const handleBlur = () => {
    if (editedName.trim() !== '') {
      dispatch(updateUserName({ id: user.id, name: editedName.trim() }));
    } else {
      setEditedName(user.name);
    }
    setIsEditing(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleBlur();
    }
  };

  return (
    <li 
      style={{ 
        cursor: 'pointer',
        color: user.isActive ? 'black' : 'gray',
        textDecoration: user.isActive ? 'none' : 'line-through'
      }}
      onClick={handleClick}
    >
      {isEditing ? (
        <input
          type="text"
          value={editedName}
          onChange={(e) => setEditedName(e.target.value)}
          onBlur={handleBlur}
          onKeyPress={handleKeyPress}
          autoFocus
        />
      ) : (
        user.name
      )}
    </li>
  );
};

export default EditableUserItem;