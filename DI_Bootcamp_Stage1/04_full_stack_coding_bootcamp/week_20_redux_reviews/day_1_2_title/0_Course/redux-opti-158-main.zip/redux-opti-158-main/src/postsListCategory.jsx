import React from "react";
import { useSelector } from "react-redux";
import { createSelector } from "@reduxjs/toolkit";

// Base selector for posts
const selectPostsState = (state) => state.posts;

// Memoized selector for posts by category
const selectPostsByCategory = createSelector(
  [selectPostsState, (state, category) => category],
  (posts, category) => posts.filter((post) => post.category === category)
);

export default function PostList({ category }) {
  const posts = useSelector((state) => selectPostsByCategory(state, category));

  return (
    <ul>
      {posts.map((post) => (
        <li key={post.id}>{post.title}</li>
      ))}
    </ul>
  );
};
