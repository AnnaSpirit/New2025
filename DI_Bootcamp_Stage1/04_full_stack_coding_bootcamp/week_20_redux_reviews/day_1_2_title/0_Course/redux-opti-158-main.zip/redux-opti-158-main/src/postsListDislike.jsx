import React from 'react';
import { useDispatch, useSelector, useCallback } from 'react-redux';
import { likePost, dislikePost } from './postSlice';

export default function PostList() {
  const dispatch = useDispatch();
  const posts = useSelector((state) => state.posts);

  const oldHandleAction = (postId, isLiked) => {
    if (isLiked) {
      dispatch(dislikePost(postId));
    } else {
      dispatch(likePost(postId));
    }
  };

  const handleAction = useCallback(
    oldHandleAction
    ,
    [dispatch]
  )

  return (
    <ul>
      {posts.map((post) => (
        <li key={post.id}>
          {post.title}
          <button onClick={() => handleAction(post.id, post.isLiked)}>
            {post.isLiked ? 'Dislike' : 'Like'}
          </button>
        </li>
      ))}
    </ul>
  );
};