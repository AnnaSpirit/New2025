import React from "react";
import { useSelector } from "react-redux";
import ActiveUsersComponent from "./ActiveUsersComponent";
import EditableUserItem from "./components/EditableUserItem";

const UserComponent = () => {
  const users = useSelector((state) => state.users.users);
  
  return (
    <>
      <h2>All Users (Click to Edit)</h2>
      <ul>
        {users.map((user) => (
          <EditableUserItem key={user.id} user={user} />
        ))}
      </ul>

      <h2>Active Users Only</h2>
      <ActiveUsersComponent />
    </>
  );
};

export default UserComponent;
