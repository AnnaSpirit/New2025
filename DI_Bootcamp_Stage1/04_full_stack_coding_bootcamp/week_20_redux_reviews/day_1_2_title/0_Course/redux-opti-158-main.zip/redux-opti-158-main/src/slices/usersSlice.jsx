import { createSlice } from '@reduxjs/toolkit';

const usersSlice = createSlice({
  name: 'users',
  initialState: {
    users: [
        {
            id: 1,
            name: 'John Doe',
            email: 'john.doe@example.com',
            isActive: true,
        },
        {
            id: 2,
            name: 'Jane Doe',
            email: 'jane.doe@example.com',
            isActive: false,
        },
    ],
  },
  reducers: {
    updateUserName: (state, action) => {
      const { id, name } = action.payload;
      const user = state.users.find(user => user.id === id);
      if (user) {
        user.name = name;
      }
    }
  }
});

export const { updateUserName } = usersSlice.actions;
export default usersSlice.reducer;