import { createSelector } from '@reduxjs/toolkit';

// Base selector
const selectUsersState = state => state.users;

// Memoized selector for all users
export const selectAllUsers = createSelector(
  [selectUsersState],
  usersState => usersState.users
);

// Memoized selector for active users
export const selectActiveUsers = createSelector(
  [selectAllUsers],
  users => users.filter(user => user.isActive)
);