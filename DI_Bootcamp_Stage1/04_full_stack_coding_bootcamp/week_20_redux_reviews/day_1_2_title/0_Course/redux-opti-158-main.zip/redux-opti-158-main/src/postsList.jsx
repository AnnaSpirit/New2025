import React from 'react';
import { useDispatch, useSelector, useCallback } from 'react-redux';
import { likePost } from './postSlice';

export default function PostList() {
  const dispatch = useDispatch();
  const posts = useSelector((state) => state.posts);

  const oldHandleLike = (postId) => {
    dispatch(likePost(postId))
  };

  const handleLike = useCallback(
    oldHandleLike,
    [dispatch]
  )

//   const handleLike = useCallback(
//     (postId) => {
//         dispatch(likePost(postId))
//     },
//     [dispatch]
//   )

  return (
    <ul>
      {posts.map((post) => (
        <li key={post.id}>
          {post.title}
          <button onClick={() => handleLike(post.id)}>Like</button>
        </li>
      ))}
    </ul>
  );
}